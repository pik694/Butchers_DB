create procedure recipes_generator as
  type str_table is table of varchar2(32);
  meats str_table;
  kinds str_table;
  meat_nr integer;
  kind_nr integer;
  begin
    meats := str_table ('kielbasa', 'szynka', 'wedlina', 'galareta', 'pieczeń', 'kaszanka');
    kinds := str_table ('swojska', 'podwędzana', 'górnicza', 'jałowcowa', 'dymiona', 'z beczki', 'czarna', 'soczysta');
    for i in 1..128 loop
      meat_nr := dbms_random.value(1, meats.count);
      kind_nr := dbms_random.value(1, kinds.count);
      insert into recipes values (meats(meat_nr) || ' ' || kinds(kind_nr)|| ' ' || to_char(i));
    end loop;
    dbms_output.put_line('Added 128 recipes');
  end;