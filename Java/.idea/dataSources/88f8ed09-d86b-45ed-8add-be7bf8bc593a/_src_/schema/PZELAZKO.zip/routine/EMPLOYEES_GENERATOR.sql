create procedure employees_generator as
  type str_table is table of varchar2(256);
  names str_table;
  surnames str_table;
  phone_nr integer (10);
  random_name integer (10);
  random_surname integer (10);
  random_phone_number integer (10);
  begin
    names := str_table ('Adam', 'Adrian', 'Krzysztof', 'Daniel', 'Zdzislaw', 'Mariusz', 'Piotr', 'Paweł', 'Zbigniew', 'Władysław', 'Jan', 'Robert', 'Grzegorz', 'Fabian', 'Michał', 'Włodzimierz', 'Waldemar', 'Janusz', 'Edward', 'Mateusz');
    surnames := str_table ('Nowak', 'Kowalski', 'Wiśniewski', 'Wójcik', 'Kowalczyk', 'Woźniak', 'Lewandowski', 'Kamiński', 'Zieliński', 'Szymański', 'Dąbrowski', 'Jankowski', 'Kozłowski', 'Mazur', 'Wojciechowski', 'Krawczyk', 'Kwiatkowski');

    for i in 1..1000 loop
      random_name := dbms_random.value(1, names.count);
      random_surname := dbms_random.value(1, surnames.count);
      random_phone_number := dbms_random.value(500000000, 899999999);
      insert into employees values (null, names(random_name), surnames (random_surname), to_char(random_phone_number));
    end loop;
  dbms_output.put_line ('Added 1000 employees');
  end;