create procedure departments_generator as
    type str_table is table of varchar2(32);
    manager integer;
    names str_table;
  begin
    names := str_table ('A', 'B', 'C', 'D', 'E');
    for i in 1..names.count loop
      insert into departments (name, manager) values ( names (i), (select * from (select id from employees order by dbms_random.value) where rownum = 1));
    end loop;
    dbms_output.put_line('Added ' || to_char(names.count) || ' departments');
  end;