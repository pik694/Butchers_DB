create procedure ingredients_generator as
  name varchar2(32);
  price decimal(6,2);

  begin
    for i in 1..128 loop
      name := dbms_random.string('u', 16);
      price := dbms_random.value (0, 999999) / 100;
      insert into ingredients (name, price_per_unit) values (name, price);
    end loop;
    dbms_output.put_line('Added 32 ingredients');
  end;