create procedure shifts_generator as
  begin
    for i in 1..100 loop
      insert into shifts (date_of_shift, department) values (
             (select to_date('1999-01-01','yyyy-mm-dd') + trunc(dbms_random.value(1,10000)) from dual),
             (select * from (select id from departments order by dbms_random.value) where rownum = 1));
    end loop;
  end;