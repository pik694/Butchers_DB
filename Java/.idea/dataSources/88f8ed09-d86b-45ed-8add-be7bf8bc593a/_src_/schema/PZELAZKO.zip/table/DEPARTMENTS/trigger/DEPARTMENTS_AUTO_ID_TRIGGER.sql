create trigger DEPARTMENTS_AUTO_ID_TRIGGER
	before insert
	on DEPARTMENTS
	for each row
begin
    :new.id := departments_sequence.nextval;
  end;