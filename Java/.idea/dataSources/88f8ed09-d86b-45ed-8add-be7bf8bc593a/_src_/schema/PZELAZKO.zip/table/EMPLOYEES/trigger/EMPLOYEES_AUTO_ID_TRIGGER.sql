create trigger EMPLOYEES_AUTO_ID_TRIGGER
	before insert
	on EMPLOYEES
	for each row
begin
    :new.id := employees_sequence.nextval;
  end;