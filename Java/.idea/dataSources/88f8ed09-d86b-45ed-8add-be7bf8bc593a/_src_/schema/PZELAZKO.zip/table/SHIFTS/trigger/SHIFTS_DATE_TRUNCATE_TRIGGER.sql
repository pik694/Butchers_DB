create trigger SHIFTS_DATE_TRUNCATE_TRIGGER
	before insert or update
	on SHIFTS
	for each row
begin
    :new.date_of_shift := trunc(:new.date_of_shift);
  end;